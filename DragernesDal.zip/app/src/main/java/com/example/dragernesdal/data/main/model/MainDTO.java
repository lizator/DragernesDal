package com.example.dragernesdal.data.main.model;

public class MainDTO{
    String info;

    public MainDTO(String info) {
        this.info = info;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
